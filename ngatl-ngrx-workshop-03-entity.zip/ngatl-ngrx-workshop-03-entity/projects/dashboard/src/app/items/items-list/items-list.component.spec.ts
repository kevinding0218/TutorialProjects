/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ItemsListComponent } from './items-list.component';

describe('Component: ItemsList', () => {
  it('should create an instance', () => {
    const component = new ItemsListComponent();
    expect(component).toBeTruthy();
  });
});
