export interface Widget {
  id: string;
  name: string;
  price: number;
  description?: string;
}
