/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ItemDetailComponent } from './item-detail.component';

describe('Component: ItemDetail', () => {
  it('should create an instance', () => {
    const component = new ItemDetailComponent();
    expect(component).toBeTruthy();
  });
});
