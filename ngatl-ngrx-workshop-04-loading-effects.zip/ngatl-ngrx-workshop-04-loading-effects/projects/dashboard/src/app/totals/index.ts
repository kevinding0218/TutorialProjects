export { TotalsViewModule } from './totals-view.module';
export { TotalsComponent } from './totals/totals.component';
