# NgrxDemo

Demo showing NgRx with Angular
