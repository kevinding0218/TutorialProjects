export class Villain {
  id: number;
  name: string;
  saying: string;
}
